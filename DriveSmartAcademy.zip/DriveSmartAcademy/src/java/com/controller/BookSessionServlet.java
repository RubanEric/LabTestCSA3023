/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.SessionDAO;
import com.model.SessionBean;

@WebServlet("/BookSessionServlet")
public class BookSessionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String studentName =
                request.getParameter("student_name");

        String branchLocation =
                request.getParameter("branch_location");

        String lessonType =
                request.getParameter("lesson_type");

        SessionBean session = new SessionBean();

        session.setStudentName(studentName);
        session.setBranchLocation(branchLocation);
        session.setLessonType(lessonType);
        session.setStatus("Booked");

        SessionDAO dao = new SessionDAO();

        dao.bookSession(session);

        response.sendRedirect("ScheduleServlet");
    }
}
