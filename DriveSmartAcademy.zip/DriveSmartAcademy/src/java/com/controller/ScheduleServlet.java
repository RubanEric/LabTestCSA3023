/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.SessionDAO;
import com.model.SessionBean;

@WebServlet("/ScheduleServlet")
public class ScheduleServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        SessionDAO dao = new SessionDAO();

        List<SessionBean> list =
                dao.getAllSessions();

        request.setAttribute("sessionList", list);

        RequestDispatcher rd =
                request.getRequestDispatcher("schedule.jsp");

        rd.forward(request, response);
    }
}

