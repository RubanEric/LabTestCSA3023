/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.model.SessionBean;

public class SessionDAO {

    private String jdbcURL =
            "jdbc:mysql://localhost:3306/drivesmart_db";
    private String jdbcUser = "root";
    private String jdbcPassword = "";

    private static final String INSERT_SESSION =
            "INSERT INTO Training_Sessions(student_name,branch_location,lesson_type,status) VALUES(?,?,?,?)";

    private static final String SELECT_ALL =
            "SELECT * FROM Training_Sessions ORDER BY branch_location ASC";

    public Connection getConnection() {

        Connection conn = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(
                    jdbcURL,
                    jdbcUser,
                    jdbcPassword);

        } catch(Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

    public boolean bookSession(SessionBean session) {

        boolean rowInserted = false;

        try(Connection conn = getConnection();
            PreparedStatement ps =
                    conn.prepareStatement(INSERT_SESSION)) {

            ps.setString(1, session.getStudentName());
            ps.setString(2, session.getBranchLocation());
            ps.setString(3, session.getLessonType());
            ps.setString(4, session.getStatus());

            rowInserted = ps.executeUpdate() > 0;

        } catch(Exception e) {
            e.printStackTrace();
        }

        return rowInserted;
    }

    public List<SessionBean> getAllSessions() {

        List<SessionBean> list = new ArrayList<>();

        try(Connection conn = getConnection();
            PreparedStatement ps =
                    conn.prepareStatement(SELECT_ALL);
            ResultSet rs = ps.executeQuery()) {

            while(rs.next()) {

                SessionBean session = new SessionBean();

                session.setSessionId(rs.getInt("session_id"));
                session.setStudentName(rs.getString("student_name"));
                session.setBranchLocation(rs.getString("branch_location"));
                session.setLessonType(rs.getString("lesson_type"));
                session.setStatus(rs.getString("status"));

                list.add(session);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}

   