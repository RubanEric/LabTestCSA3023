<%-- 
    Document   : index
    Created on : 16 Jun 2026, 3:13:29 PM
    Author     : MP3 LECT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.html" %>

<html>
<head>
<title>DriveSmart Academy</title>
</head>

<body>

<h2>Central Navigation Menu</h2>

<ul>
    <li>
        <a href="book_session.jsp">
            Book Driving Session
        </a>
    </li>

    <li>
        <a href="ScheduleServlet">
            View Schedule Dashboard
        </a>
    </li>
</ul>

</body>
</html>

<%@ include file="footer.jsp" %>

