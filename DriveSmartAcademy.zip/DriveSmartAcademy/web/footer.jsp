<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 3:10:21 PM
    Author     : MP3 LECT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <body>
       <div style="background:#f1f1f1;
            text-align:center;
            padding:10px;
            margin-top:20px;">

    Current Date & Time:
    <%= new java.util.Date() %>

</div>

    </body>
</html>
