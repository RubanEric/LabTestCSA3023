<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 3:15:42 PM
    Author     : MP3 LECT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%@ page import="com.model.SessionBean" %>

<%@ include file="header.html" %>

<html>
<head>
<title>Schedule Dashboard</title>
</head>

<body>

<h2>Centralized Schedule Dashboard</h2>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Student Name</th>
    <th>Branch</th>
    <th>Lesson Type</th>
    <th>Status</th>
</tr>

<%
List<SessionBean> sessionList =
(List<SessionBean>)request.getAttribute("sessionList");

if(sessionList != null){

    for(SessionBean s : sessionList){
%>

<tr>
    <td><%= s.getSessionId() %></td>
    <td><%= s.getStudentName() %></td>
    <td><%= s.getBranchLocation() %></td>
    <td><%= s.getLessonType() %></td>
    <td><%= s.getStatus() %></td>
</tr>

<%
    }
}
%>

</table>

</body>
</html>

<%@ include file="footer.jsp" %>
