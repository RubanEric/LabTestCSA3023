<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:14:41 PM
    Author     : MP3 LECT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.html" %>

<html>
<head>
<title>Book Session</title>
</head>

<body>

<h2>Book Driving Session</h2>

<form method="POST"
      action="BookSessionServlet">

    Student Name:
    <input type="text"
           name="student_name"
           required>
    <br><br>

    Branch Location:
    <select name="branch_location">

        <option>Kuala Lumpur</option>
        <option>Penang</option>
        <option>Johor</option>

    </select>

    <br><br>

    Lesson Type:
    <select name="lesson_type">

        <option>Manual Car</option>
        <option>Automatic Car</option>
        <option>Motorcycle</option>

    </select>

    <br><br>

    <input type="submit"
           value="Book Session">

</form>

</body>
</html>

<%@ include file="footer.jsp" %>

